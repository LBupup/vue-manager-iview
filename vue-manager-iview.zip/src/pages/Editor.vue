<template v-if="isRouterAlive">
  		<!--轮播-->
		<div class="lb_gl">
			<div class="container">
				<h1 class="turn_3d">普杰科技人脸识别</h1>
<div id="gallery">
<div id="gallery_output">
 <div class="container" id="img1">
        <div class="player">
        <video-player class="video-player vjs-custom-skin"
            ref="videoPlayer"
            :playsinline="true"
            :options="playerOptions"
        ></video-player>
       </div>
 </div>
<!-- <img id="img2" src="../assets/img/img-2.jpg" /> -->
</div>
<div id="gallery_nav">
<a rel="img1" href="javascript:;">1</a>
<a rel="img2" href="javascript:;">2</a>
</div>

<div class="clear"></div>
</div>
				<div class="pictureSlider poster-main">
					<div class="poster-btn poster-prev-btn"></div>
					<ul id="zturn2" class="poster-list">
						<li class="poster-item  zturn-item">
							<p class="xxgy">陌生人1</p>
							<p class="say">昵称</p>
							<div class="for_btn">
								<img src="../assets/img/2.gif" width="100%">
								<a href="#" class="in_page"><img src="../assets/img/iconin.png" /></a>
							</div>

							<div class="students_star">
								<p class="cell_list"><span class="lf">姓名：<span class="darks">小明</span></span> <span class="rt">性别 ：<span class="darks">男</span></span>
								</p>
								<p class="cell_list"><span>房间号：<span class="darks">8808</span></span>
								</p>
								<div class="zwjs">
									
								</div>
							</div>
						</li>

						<li class="poster-item zturn-item">
							<p class="xxgy">陌生人2</p>
							<p class="say">昵称</p>
							<div class="for_btn">
								<img src="../assets/img/2.gif" width="100%">
								<a href="#" class="in_page"><img src="../assets/img/iconin.png" /></a>
							</div>
							<div class="students_star">
								<p class="cell_list"><span class="lf">姓名：<span class="darks">小明</span></span> <span class="rt">性别 ：<span class="darks">男</span></span>
								</p>
								<p class="cell_list"><span>房间号：<span class="darks">8808</span></span>
								</p>
								<div class="zwjs">
									
								</div>
							</div>
						</li>

						<li class="poster-item zturn-item">
							<p class="xxgy">陌生人3</p>
							<p class="say">昵称</p>
							<div class="for_btn">
								<img src="../assets/img/2.gif" width="100%">
								<a href="#" class="in_page"><img src="../assets/img/iconin.png" /></a>
							</div>
							<div class="students_star">
								<p class="cell_list"><span class="lf">姓名：<span class="darks">小明</span></span> <span class="rt">性别 ：<span class="darks">男</span></span>
								</p>
								<p class="cell_list"><span>房间号：<span class="darks">8808</span></span>
								</p>
								<div class="zwjs">
									
								</div>
							</div>
						</li>

						<li class="poster-item zturn-item">
							<p class="xxgy">陌生人4</p>
							<p class="say">昵称</p>
							<div class="for_btn">
								<img src="../assets/img/2.gif" width="100%">
								<a href="#" class="in_page"><img src="../assets/img/iconin.png" /></a>
							</div>
							<div class="students_star">
								<p class="cell_list"><span class="lf">姓名：<span class="darks">小明</span></span> <span class="rt">性别 ：<span class="darks">男</span></span>
								</p>
								<p class="cell_list"><span>房间号：<span class="darks">8808</span></span>
								</p>
								<div class="zwjs">
									
								</div>
							</div>
						</li>

						<li class="poster-item zturn-item">
							<p class="xxgy">陌生人</p>
							<p class="say">昵称</p>
							<div class="for_btn">
								<img src="../assets/img/2.gif" width="100%">
								<a href="#" class="in_page"><img src="../assets/img/iconin.png" /></a>
							</div>
							<div class="students_star">
								<p class="cell_list"><span class="lf">姓名：<span class="darks">小明</span></span> <span class="rt">性别 ：<span class="darks">男</span></span>
								</p>
								<p class="cell_list"><span>房间号：<span class="darks">8808</span></span>
								</p>
								<div class="zwjs">
								
								</div>
							</div>
						</li>
		<li class="poster-item zturn-item">
							<p class="xxgy">陌生人</p>
							<p class="say">昵称</p>
							<div class="for_btn">
								<img src="../assets/img/2.gif" width="100%">
								<a href="#" class="in_page"><img src="../assets/img/iconin.png" /></a>
							</div>
							<div class="students_star">
								<p class="cell_list"><span class="lf">姓名：<span class="darks">小明</span></span> <span class="rt">性别 ：<span class="darks">男</span></span>
								</p>
								<p class="cell_list"><span>房间号：<span class="darks">8808</span></span>
								</p>
								<div class="zwjs">
									
								</div>
							</div>
						</li>

		<li class="poster-item zturn-item">
							<p class="xxgy">陌生人</p>
							<p class="say">昵称</p>
							<div class="for_btn">
								<img src="../assets/img/2.gif" width="100%">
								<a href="#" class="in_page"><img src="../assets/img/iconin.png" /></a>
							</div>
							<div class="students_star">
								<p class="cell_list"><span class="lf">姓名：<span class="darks">小明</span></span> <span class="rt">性别 ：<span class="darks">男</span></span>
								</p>
								<p class="cell_list"><span>房间号：<span class="darks">8808</span></span>
								</p>
								<div class="zwjs">
                  
								</div>
							</div>
						</li>

		<li class="poster-item zturn-item">
							<p class="xxgy">陌生人</p>
							<p class="say">昵称</p>
							<div class="for_btn">
								<img src="../assets/img/2.gif" width="100%">
								<a href="#" class="in_page"><img src="../assets/img/iconin.png" /></a>
							</div>
							<div class="students_star">
								<p class="cell_list"><span class="lf">姓名：<span class="darks">小明</span></span> <span class="rt">性别 ：<span class="darks">男</span></span>
								</p>
								<p class="cell_list"><span>房间号：<span class="darks">8808</span></span>
								</p>
								<div class="zwjs">
									
								</div>
							</div>
						</li>

		<li class="poster-item zturn-item">
							<p class="xxgy">陌生人</p>
							<p class="say">昵称</p>
							<div class="for_btn">
								<img src="../assets/img/2.gif" width="100%">
								<a href="#" class="in_page"><img src="../assets/img/iconin.png" /></a>
							</div>
							<div class="students_star">
								<p class="cell_list"><span class="lf">姓名：<span class="darks">小明</span></span> <span class="rt">性别 ：<span class="darks">男</span></span>
								</p>
								<p class="cell_list"><span>房间号：<span class="darks">8808</span></span>
								</p>
								<div class="zwjs">
									
								</div>
							</div>
						</li>

		<li class="poster-item zturn-item">
							<p class="xxgy">陌生人</p>
							<p class="say">昵称</p>
							<div class="for_btn">
								<img src="../assets/img/2.gif" width="100%">
								<a href="#" class="in_page"><img src="../assets/img/iconin.png" /></a>
							</div>
							<div class="students_star">
								<p class="cell_list"><span class="lf">姓名：<span class="darks">小明</span></span> <span class="rt">性别 ：<span class="darks">男</span></span>
								</p>
								<p class="cell_list"><span>房间号：<span class="darks">8808</span></span>
								</p>
								<div class="zwjs">
									
								</div>
							</div>
						</li>

		<li class="poster-item zturn-item" >
							<p class="xxgy">陌生人</p>
							<p class="say">昵称</p>
							<div class="for_btn">
								<img src="../assets/img/2.gif" width="100%">
								<a href="#" class="in_page"><img src="../assets/img/iconin.png" /></a>
							</div>
							<div class="students_star">
								<p class="cell_list"><span class="lf">姓名：<span class="darks">小明</span></span> <span class="rt">性别 ：<span class="darks">男</span></span>
								</p>
								<p class="cell_list"><span>房间号：<span class="darks">8808</span></span>
								</p>
								<div class="zwjs">
									
								</div>
							</div>
						</li>
				</ul>
				</div>
		</div>		
		</div>
</template>
<script type="text/javascript">
import $ from 'jquery'
import '../../static/zturn'
import VideoPlayer from 'vue-video-player'
require('video.js/dist/video-js.css')
require('vue-video-player/src/custom-theme.css')

export default {
  name: 'editor',
  data: function () {
    return {
			playerOptions: {
                //playbackRates: [0.7, 1.0, 1.5, 2.0], //播放速度
                autoplay: false, //如果true,浏览器准备好时开始回放。
                muted: false, // 默认情况下将会消除任何音频。
                loop: false, // 导致视频一结束就重新开始。
                preload: 'auto', // 建议浏览器在<video>加载元素后是否应该开始下载视频数据。auto浏览器选择最佳行为,立即开始加载视频（如果浏览器支持）
                language: 'zh-CN',
                aspectRatio: '16:9', // 将播放器置于流畅模式，并在计算播放器的动态大小时使用该值。值应该代表一个比例 - 用冒号分隔的两个数字（例如"16:9"或"4:3"）
                fluid: true, // 当true时，Video.js player将拥有流体大小。换句话说，它将按比例缩放以适应其容器。
                sources: [{
                    type: "application/x-mpegURL",
                    src: "http://21810.liveplay.myqcloud.com/live/21810_ea70a9e139.m3u8" //你的m3u8地址（必填）
                }],
                poster: "poster.jpg", //你的封面地址
                width: document.documentElement.clientWidth,
                notSupportedMessage: '此视频暂无法播放，请稍后再试', //允许覆盖Video.js无法播放媒体源时显示的默认信息。
                //  controlBar: {
                //   timeDivider: true,
                //   durationDisplay: true,
                //   remainingTimeDisplay: false,
                //   fullscreenToggle: true //全屏按钮
                //  }
            }
    }
  },
    provide(){
      return{
        reload:this.reload
      }
    },
    data(){
      return {
        isRouterAlive:true,
      }
    },
    methods:{
      reload(){
        this.isRouterAlive = false;
        this.$nextTick(function () {
          this.isRouterAlive = true
        });
      },
		},
		// components: {
    //     videoPlayer
    // },
  
}
</script>
<style>
.video-js{
	height: 350px!important;
}
</style>
<style scoped>
#gallery{
  height: 350px;
  margin-bottom: 10px;
}
#gallery img {
			border: none;
		}
		#gallery_nav {
			float: left;
			width: 112px;
			text-align: center;
		}
		#gallery_nav a{
      display: block;
      height: 92px;
		}
		#gallery_output {
			float: left;
      width: 900px;
      height: 500px;
			overflow: hidden;
		}

		#gallery_output img {
			display: block;
			margin: 0px auto 0 auto;
		}
		.zz{ border: 1px solid rgba(92,92,92,1.00); }

body{font-family: microsoft yahei,Arial;margin:0;padding:0;}
h1,h2,h3,h4,h5,h6,ol,li,ul,p,dl,dt,dd{padding: 0;margin:0}
ul,ol,li,dl,dt,dd{text-decoration: none;list-style: none}
.lf{float: left}
.rt{float: right}
.clear{clear:both}
.ovh{overflow: hidden}
a{  color:#303030;  text-decoration:none;  }
a:hover{  text-decoration:none;  }
input{border:none;outline:none;}
img{border:none}
.lb_gl{margin-bottom: 30px;background: url('../assets/img/bg_3d.png');background-size: 100% 100%;height:100%;}
.container{width: 1024px;margin:0 auto;position: relative;}
.pictureSlider{height: 518px;margin-bottom: 24px;}
.poster-item{background: #fff;height: 350px;width:250px;border-radius: 10px;padding:10px;
	transition: all 0.5s;cursor: default;
	-moz-transition: all 0.5s;cursor: default;
	-webkit-transition: all 0.5s;cursor: default;
	-o-transition: all 0.5s;cursor: default;
}
.turn_3d{text-align: center;color: #fff;font-weight: 400;font-size: 36px;padding: 28px 0;margin-right: 40px;}
.xxgy{font-size: 20px;font-weight: 900;padding-left: 10px;}
.poster-item .say{font-size: 18px;padding-left: 10px;}
.students_star{padding:0px 10px 0 10px;font-size: 10px;}
.cell_list{margin-bottom: 10px;color:#999;font-size: 14px;overflow: hidden;}
.darks{color: #000;padding-left: 10px;}
.zwjs{border-top:1px solid #d0cddb;line-height: 26px;padding-top: 5px;color: #999;font-size: 12px;max-height: 84px;overflow: hidden;}
.for_btn{position: relative;overflow:hidden}
.in_page{position: absolute;left: 50%;top:50%;width:40px;height: 40px;margin-left: -20px;margin-top: -20px;}
.in_page>img{width: 40px;height: 40px;}
.check_more{width: 180px;height: 50px;line-height: 50px;text-align: center;color:#fff;background: #bc241d;margin:0 auto;display: block;}
</style>

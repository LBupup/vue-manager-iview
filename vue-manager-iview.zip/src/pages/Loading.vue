<template>
  <div class="loading">
    <VmLoading>
    </VmLoading>
  </div>
</template>
<script>
  import VmLoading from '@/components/vm-loading'
  export default {
    name: 'Login',
    components: {
      VmLoading
    }
  }
</script>
